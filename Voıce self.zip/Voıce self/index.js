//666, Services : https://discord.gg/RxyDRszGAB
//666, Services : https://discord.gg/RxyDRszGAB
const Discord = require("discord.js-selfbot-v13"); 
require('dotenv').config()
const client = new Discord.Client({
    intents: [Discord.Intents.FLAGS.GUILDS]
});//666, Services : https://discord.gg/RxyDRszGAB
client.on('ready', async () => {
  console.log(`${client.user.username} is ready!\n By 666, Services : https://discord.gg/RxyDRszGAB`);
})//666, Services : https://discord.gg/RxyDRszGAB
const { joinVoiceChannel, createAudioPlayer } = require("@discordjs/voice");
const { channel } = require('diagnostics_channel');
//666, Services : https://discord.gg/RxyDRszGAB
const voiceChannelId = "1297543764843302945";
const guildId = "1182253933389938778";
//666, Services : https://discord.gg/RxyDRszGAB
client.on("ready", () => {
    const voiceChannel = client.channels.cache.get(voiceChannelId);
    if (!voiceChannel) {
      return console.log(`Voice channel ${voiceChannelId} not found.\n By 666, Services : https://discord.gg/RxyDRszGAB`);
    }
  //666, Services : https://discord.gg/RxyDRszGAB
    const connection = joinVoiceChannel({
      channelId: voiceChannelId,
      guildId: guildId,
      adapterCreator: voiceChannel.guild.voiceAdapterCreator,
    });
  //666, Services : https://discord.gg/RxyDRszGAB
    connection.on("error", (error) => {
      console.error(`Error joining voice channel: ${error.message}\n By 666, Services : https://discord.gg/RxyDRszGAB`);
    });
  //666, Services : https://discord.gg/RxyDRszGAB
    connection.on("stateChange", (state) => {
      console.log(`Connection state changed: ${state.status}\n By 666, Services : https://discord.gg/RxyDRszGAB`);
    });
  //666, Services : https://discord.gg/RxyDRszGAB
    const audioPlayer = createAudioPlayer();
    connection.subscribe(audioPlayer);
  //666, Services : https://discord.gg/RxyDRszGAB
    console.log(`Joined voice channel ${voiceChannel.name}!\n By 666, Services : https://discord.gg/RxyDRszGAB`);
  });
//666, Services : https://discord.gg/RxyDRszGAB
//666, Services : https://discord.gg/RxyDRszGAB
client.login(process.env.token);
const express = require("express");
const app = express();
app.listen(() => console.log("Server started\n By 666, Services : https://discord.gg/RxyDRszGAB"));
app.use('/ping', (req, res) => {
  res.send(new Date());

});
//666, Services : https://discord.gg/RxyDRszGAB