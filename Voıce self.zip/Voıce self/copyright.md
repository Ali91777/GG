
## Discord Bot Project Copyright

All rights reserved to **@e1r_** with the following details:
- **Discord ID**: `1142824627001888820`
- **Server**: [https://discord.gg/RxyDRszGAB](https://discord.gg/RxyDRszGAB)

### Permissions
- **@e1r_** with the specified Discord ID and server is the sole owner and has exclusive rights to this project.
- No one other than **@e1r_** may edit, modify, distribute, or resell this project in any form.

### Restrictions
- **Editing**: This project cannot be edited by anyone except **@e1r_**.
- **Reselling**: Any attempt to resell, redistribute, or claim ownership of this project by others is strictly prohibited.
- **Servers**: This project is officially linked to and managed under the server **https://discord.gg/RxyDRszGAB**.

### Violations
Any unauthorized use, modification, or redistribution of this project will be considered a violation of these terms and may lead to appropriate actions, including but not limited to:
- Reporting to Discord for intellectual property infringement.
- Legal actions as per applicable laws.

---
Copyright © 2024 **@e1r_**
All rights reserved.
